# it3100
                                    ĐỒ ÁN MÔN HỌC LẬP TRÌNH HƯỚNG ĐỐI TƯỢNG

- Tên đề tài : Chương trình chiếc nón kì diệu
- Cơ sở lý thuyết : Các tài liệu về phân tích thiết kế hướng đối tượng, lập trình hướng đối tượng,
lập trình đồ họa, quản lý dữ liệu.

- Mô tả yêu cầu :
<br> - Xây dựng một chương trình cho phép người chơi tham gia gameshow Chiếc nón kì diệu qua máy
tính.
<br> - Lực quay nón xác định bởi thao tác kéo chuột (chương trình có lực kế cho xem mức độ mạnh
yếu).
<br> - Về thang chia các điểm 100, 200, 300,400, 500, 600, 700, 800, 900, Mất điểm, Mất lượt,
thêm lượt, phần thưởng có thể chỉ định trước khi chạy chương trình.
<br> - Chương trình có chức năng quản trị: Cho phép ra các ô chữ (1hàng) cho các lượt chơi. Số
lượt chơi bằng số người chơi + 1(vòng thi đặc biệt). Thiết lập các phần thưởng.
<br> - Thực hiện chơi, thống kê điểm.

- Nội dung công việc :
<br> - Thiết kế hướng đối tượng cho một trò chơi tương tác.
<br> - Xây dựng thuật toán xác định vị trí điểm dừng của con trỏ khi dừng quay.
<br> - Lập trình đồ họa.
<br> - Việc mô phỏng thao tác quay nón không nhất thiết cần giống như thực tế (tốc độ quay giảm
dần – tuy nhiên nếu thực hiện được sẽ được cộng điểm).
