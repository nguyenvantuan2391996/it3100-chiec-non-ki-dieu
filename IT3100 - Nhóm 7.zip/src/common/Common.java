//package common;
//
//import java.util.ArrayList;
//
//import javax.swing.JButton;
//import javax.swing.JComboBox;
//import javax.swing.JLabel;
//import javax.swing.JScrollPane;
//import javax.swing.JTable;
//import javax.swing.JTextField;
//
//import model.ManageQuestion;
//import model.PlayGame;
//import model.Question;
//import view.AdminJframe;
//import view.CreatePlayerJframe;
//import view.GameJframe;
//import view.HelpJframe;
//
//public class Common {
//	public static PlayGame playGame = new PlayGame();
//	public static String answer;
//	//
//	public static AdminJframe adminJframe;
//	public static HelpJframe helpJframe;
//	public static CreatePlayerJframe playerJframe;
//	public static GameJframe gameJframe;
//	public ManageQuestion manageQuestion = new ManageQuestion();
//	public static Question question = new Question();
//	public static int oChu;
//	public static int round = 1;
//	public static ArrayList<String> listTopicUsed = new ArrayList<>(); // danh sách topic đã chơi
//	//
//	public static JButton buttonMenu[][] = new JButton[1][5];
//	public static JTextField jTextField[][] = new JTextField[1][5];
//	public static JLabel jLabel[][] = new JLabel[1][5];
//	public static JTable tableManageQuestion;
//	public static JScrollPane spTable;
//	//
//	public static JButton buttonPlayer[][] = new JButton[1][2];
//	public static JLabel jLabelPlayer[][] = new JLabel[1][4];
//	public static JTextField jTextFieldPlayer[][] = new JTextField[1][3];
//	public static JComboBox jComboBox;
//	//
//	public static JButton buttonPlay[][] = new JButton[2][13];
//	public static JButton buttonAnswer;
//	public static JButton buttonNext;
//	public static JLabel label[] = new JLabel[10];
//	public static JButton labelOChu[];
//	//
//	public static JLabel label[][] = new JLabel[1][5];
//	public static JButton buttonHelp;
//}
